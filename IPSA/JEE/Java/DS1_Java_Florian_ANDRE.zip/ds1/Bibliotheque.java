package ds1;
public class Bibliotheque {
    Document[] stock;
    public Bibliotheque(Document[] stock){
        this.stock = stock;
    }
}
